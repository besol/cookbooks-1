default[:ipsec][:nat_traversal] = "yes"
default[:ipsec][:shared_secret] = "my_insecure_secret"
