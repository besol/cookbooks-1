name 'gluster'
maintainer 'Heavy Water Ops, LLC'
maintainer_email 'support@hw-ops.com'
license 'Apache 2.0'
description 'Setups up the GlusterFS'

version '0.1.0'

supports 'ubuntu'

depends 'apt'
