Gluster Cookbook
==========================

Install a basic GlusterFS setup

Usage
===============

include `recipe[gluster]`
