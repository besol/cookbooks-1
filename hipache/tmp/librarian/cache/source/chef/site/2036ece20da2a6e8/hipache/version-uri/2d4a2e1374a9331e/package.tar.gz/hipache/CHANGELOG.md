Hipache Cookbook CHANGELOG
==========================

v0.2.0 (2015-04-14)
-------------------
- Ship ChefSpec matchers with the cookbook

v0.1.0 (2014-08-18)
-------------------
- Initial release!
- Standard direct install only (i.e. no Docker container installs yet)

v0.0.1 (2014-08-12)
-------------------
- Development started
