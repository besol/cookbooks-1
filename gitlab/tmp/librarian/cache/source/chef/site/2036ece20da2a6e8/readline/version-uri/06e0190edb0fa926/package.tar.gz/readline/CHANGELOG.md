v0.0.4
------

* Add Fedora

v0.0.3
------

* Clean up code for public release
* Add platform specific values

v0.0.2
------

  Initial recipe
