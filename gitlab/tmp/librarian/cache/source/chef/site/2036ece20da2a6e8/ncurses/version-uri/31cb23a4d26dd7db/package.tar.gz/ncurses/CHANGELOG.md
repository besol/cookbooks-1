v0.0.3
------

* Add rubocop, update metadata, add Fedora

v0.0.2
------

Add Travis CI badge

v0.0.1
------

* Initial public release
