default[:loggly][:loggly_python][:version] = "0.1.5"
default[:loggly][:username] = ""
default[:loggly][:password] = ""
default[:loggly][:domain] = ""
default[:loggly][:compiletime] = false