## v1.0.1:

* Clean up init script.

## v1.0.0:

* Replace obsolete Chef Software, Inc. cookbook with a current one.
* Update to JIRA 6.2.7.

## v0.9.2:

* [COOK-2265] - pin runit dependency

## v0.9.0:

* [COOK-1869] - Foodcritic fixes for Jira cookbook

## v0.8.2:

* Current public release
