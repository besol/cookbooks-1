Chef Sugar Changelog
=========================
This file is used to list changes made in each version of the chef-sugar cookbook and gem.


v1.0.1 (2013-10-15)
-------------------
- Add development recipe
- Add `compile_time`, `before`, and `after` filters

v1.0.0 (2013-10-15)
-------------------
- First public release
