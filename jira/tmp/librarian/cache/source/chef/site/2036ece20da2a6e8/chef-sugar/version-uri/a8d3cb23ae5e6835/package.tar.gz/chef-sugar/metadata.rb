name             'chef-sugar'
maintainer       'Seth Vargo'
maintainer_email 'sethvargo@gmail.com'
license          'Apache 2.0'
description      'Installs chef-sugar. Please see the chef-sugar ' \
                 'Ruby gem for more information.'
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
version          '1.0.0'
