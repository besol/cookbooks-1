## v1.0.2:

* [COOK-1098] - Add Amazon Linux platform support
* [COOK-1149] - Add OS X platform support
