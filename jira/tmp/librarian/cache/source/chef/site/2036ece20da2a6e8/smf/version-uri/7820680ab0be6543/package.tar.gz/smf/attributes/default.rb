default['nokogiri'] = {
  'version' => '1.5.2'
}
