Chef Sugar Changelog
=========================
This file is used to list changes made in each version of the chef-sugar cookbook and gem.

v1.0.0 (TBD)
------------
- First public release
