jetty cookbook
--------------

v0.1.5
------
- reverting OpenSSL module namespace change

v0.1.4
------
- Updating to work with latest openssl cookbook

v0.1.2
------
- [COOK-2964]: jetty cookbook has foodcritic failures

v0.1.0
------
- [COOK-1434] - Add cargo remote deploy support
