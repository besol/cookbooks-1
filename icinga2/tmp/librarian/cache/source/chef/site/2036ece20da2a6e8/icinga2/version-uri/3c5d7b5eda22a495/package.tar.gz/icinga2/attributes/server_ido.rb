
default['icinga2']['ido']['type'] = 'mysql'
default['icinga2']['ido']['load_schema'] = false
default['icinga2']['ido']['db_host'] = 'localhost'
default['icinga2']['ido']['db_name'] = 'icinga'
default['icinga2']['ido']['db_user'] = 'icinga'
default['icinga2']['ido']['db_password'] = 'icinga'
