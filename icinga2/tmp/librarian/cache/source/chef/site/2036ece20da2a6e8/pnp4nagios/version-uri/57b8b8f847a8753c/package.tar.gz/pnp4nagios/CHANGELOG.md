pnp4nagios CHANGELOG
====================

This file is used to list changes made in each version of the pnp4nagios cookbook.

0.2.1
-----

- Virender Khatri - fix for #1, changed tmpdir location from /tmp


0.2.0
-----

- Virender Khatri - applied temp fix for rrdcache socket connect error

- Virender Khatri - added notify to files / templates resources

- Virender Khatri - default to nagios spool directory


0.1.5
-----

- Virender Khatri - fixed incorrect dir management for spool dir

- Virender Khatri - added rra.cfg file


0.1.2
-----

- Virender Khatri - Initial release of pnp4nagios

- - -
Check the [Markdown Syntax Guide](http://daringfireball.net/projects/markdown/syntax) for help with Markdown.

The [Github Flavored Markdown page](http://github.github.com/github-flavored-markdown/) describes the differences between markdown on github and standard markdown.
