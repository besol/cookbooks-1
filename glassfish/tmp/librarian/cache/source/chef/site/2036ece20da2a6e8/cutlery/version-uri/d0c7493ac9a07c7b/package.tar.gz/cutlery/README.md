# Description

[![Build Status](https://secure.travis-ci.org/realityforge/chef-cutlery.png?branch=master)](http://travis-ci.org/realityforge/chef-cutlery)

Cutlery is a cookbook containing a collection useful library code.

# Requirements

## Platform:

*No platforms defined*

## Cookbooks:

* partial_search

# Attributes

*No attributes defined*

# Recipes

*No recipes defined*

# License and Maintainer

Maintainer:: Peter Donald (<peter@realityforge.org>)

License:: Apache 2.0
