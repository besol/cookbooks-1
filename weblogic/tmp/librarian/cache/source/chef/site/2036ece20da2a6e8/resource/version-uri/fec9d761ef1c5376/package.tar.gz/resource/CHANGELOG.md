Resource Cookbook CHANGELOG
===========================

0.2.2 (4/1/2015)
-----------------

- Fix issue with uploading via berks (@damascus)

0.2.1 (2/19/2015)
-----------------

- Rename ChefResource.resource -> Chef.resource
- Get cookbook include working again

0.2 (2/19/2015)
---------------

- Initial publication
- Single-file resources
- depends "resource" is how you use it
- Read/write resources with load/converge
- define, defaults, resource keywords
- strongly typed properties and coercion
