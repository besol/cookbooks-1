# Oracle Inventory Cookbook
This cookbook installs the oraInst.loc file into a specified location

### Platform
The following platforms have been tested with this cookbook, meaning that the
recipes run on these platforms without error:

* RedHat
* CentOS

