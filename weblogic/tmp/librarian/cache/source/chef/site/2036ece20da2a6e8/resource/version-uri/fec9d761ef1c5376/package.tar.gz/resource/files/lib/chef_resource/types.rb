module ChefResource
  module Types
  end
end
