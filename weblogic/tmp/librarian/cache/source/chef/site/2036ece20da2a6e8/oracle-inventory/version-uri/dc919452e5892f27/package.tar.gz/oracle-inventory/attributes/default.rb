default['oracle']['inventory']['group'] = 'dba'
default['oracle']['inventory']['user'] = 'oracle'
default['oracle']['inventory']['oraInst'] = '/etc/oraInst.loc'
default['oracle']['inventory']['location'] = '/opt/oracle/inventory'
