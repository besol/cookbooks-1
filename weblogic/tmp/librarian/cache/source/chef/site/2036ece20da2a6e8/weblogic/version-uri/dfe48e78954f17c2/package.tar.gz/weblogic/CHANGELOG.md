weblogic Cookbook CHANGELOG
========================
v2.0.1 (2015-05-27)
Fixed issue #3: removed reference to old cookbook name.  Weblogic 12.1.1/12.1.2 tests working.

v2.0.0 (2015-05-21)
Bumped version to work around conflict.

v1.0.0 (2015-05-14)
Added waffle.io badge.

v0.1.1 (2015-05-10)
Initial release.

This now uses the resource cookbook which is currently under active development.
https://github.com/chef-cookbooks/resource