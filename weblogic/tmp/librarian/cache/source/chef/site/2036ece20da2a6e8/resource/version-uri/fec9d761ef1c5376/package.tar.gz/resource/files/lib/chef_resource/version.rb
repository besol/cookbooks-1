module ChefResource
  VERSION = '0.2.2'
end
