name "hipchat"
maintainer "Cameron Johnston"
maintainer_email "cameron@rootdown.net"
description "LWRP for sending messages to HipChat rooms"
version "0.4.0"

depends "chef_handler"
