# values are required for token and room attrs
default['hipchat']['handler']['server'] = 'https://api.hipchat.com'
default['hipchat']['handler']['api_version'] = 'v1'
default['hipchat']['handler']['token'] = nil
default['hipchat']['handler']['room'] = nil
default['hipchat']['handler']['enabled'] = false
# values for name, color and notify_users attrs are optional
default['hipchat']['handler']['name'] = nil
default['hipchat']['handler']['color'] = nil
default['hipchat']['handler']['notify_users'] = nil
