default['hipchat']['hipchat_version'] = '1.2.0'
default['hipchat']['httparty_version'] = '0.11.0'
