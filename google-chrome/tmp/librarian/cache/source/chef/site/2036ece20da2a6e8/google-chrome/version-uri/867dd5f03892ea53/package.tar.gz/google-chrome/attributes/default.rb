
default['google-chrome']['track'] = 'stable'
