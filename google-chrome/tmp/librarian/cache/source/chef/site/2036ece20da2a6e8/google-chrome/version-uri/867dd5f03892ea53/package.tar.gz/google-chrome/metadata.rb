maintainer       "Justin Huff"
maintainer_email "jjhuff@mspin.net"
license          "Apache 2.0"
description      "Installs Google Chrome"
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
version          "0.0.1"
depends          "apt" 
supports         "ubuntu"
