name             'cloudflare'
maintainer       'Jean Rouge'
maintainer_email 'jer329@cornell.edu'
license          'unlicense'
description      'Registers your server with Cloudflare\'s DNS service'
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
version          '0.1.8'
