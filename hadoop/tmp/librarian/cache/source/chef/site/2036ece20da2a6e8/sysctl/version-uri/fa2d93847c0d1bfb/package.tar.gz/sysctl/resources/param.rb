actions :apply, :remove
default_action :apply

attribute :key, :kind_of => String
attribute :value, :required => true
